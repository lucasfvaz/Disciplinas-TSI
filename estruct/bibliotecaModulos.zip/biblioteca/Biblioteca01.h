#ifndef BIBLIOTECA01_H_INCLUDED
#define BIBLIOTECA01_H_INCLUDED

int multiplo(int V, int k);
int primo(int V);

#endif // BIBLIOTECA01_H_INCLUDED
