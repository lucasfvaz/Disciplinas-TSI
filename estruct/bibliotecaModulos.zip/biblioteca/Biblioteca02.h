#ifndef BIBLIOTECA02_H
#define BIBLIOTECA02_H

#include "Biblioteca01.h"

int primoSuperticioso(int v);
int numeroPerfeito(int v);

#endif
